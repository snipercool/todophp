<?php

require_once("Db.class.php");

class Lists {


    public static function create($list, $user) {
        try {
                    $conn = Db::getInstance();
                    $stmt = $conn->prepare("INSERT INTO `list` (name,user_id) values (:name,:user_id)");
                    $stmt->bindParam(":name", $list);
                    $stmt->bindParam(":user_id", $user);
                    $stmt->execute();
                
                    return true;
    
            } catch ( Throwable $t ) {
                return false;
    
            }
    }
    public static function getAll($userid) {
        $conn = Db::getInstance();
        $statement = $conn->prepare('select * from list where user_id = :user_id ORDER BY time ASC');
        $statement->bindParam(':user_id', $userid);
        $statement->execute();
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }
}



